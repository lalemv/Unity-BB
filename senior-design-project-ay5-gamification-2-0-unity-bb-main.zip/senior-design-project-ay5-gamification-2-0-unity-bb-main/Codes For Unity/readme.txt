Here we Located codes that will be used for our project.
